
Thank you for choosing Glossier theme!


Here are some helpful links from cmsmasters ecosystem for you:


https://glossier.cmsmasters.net/ - landing page with 6 Demo variations and theme features

https://docs.cmsmasters.net/how-to-install-glossier-theme/ - a detailed guide on all theme functionality, constantly updated and extended

https://cmsmasters.studio/help-center/ - contact us for assistance, questions and to chat!



Have fun! 